# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/mac_randomization
- Tests: 1
- Passed: 1
- Failed: 0
- Skipped: 8

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/mac_randomization/run.log
- /var/tmp/rustyjack-tests/20260215-204314/mac_randomization/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/mac_randomization/report.md

## MAC Randomization Summary
- Interface: wlan0
- Baseline MAC (sysfs): 88:a2:9e:4f:11:83
- Vendor test: enabled (Apple)
- Stress loops: 10
- Unit tests: enabled
- Negative tests: enabled
