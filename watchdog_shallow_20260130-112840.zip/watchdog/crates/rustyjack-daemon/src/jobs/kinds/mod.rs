mod hotspot_start;
mod core_command;
mod interface_select;
mod mount_start;
mod noop;
mod portal_start;
mod scan;
mod sleep;
mod unmount_start;
mod update;
mod wifi_connect;
mod wifi_scan;

use std::future::Future;

use tokio_util::sync::CancellationToken;
use std::sync::Arc;

use rustyjack_ipc::{DaemonError, ErrorCode, JobKind};
use crate::state::DaemonState;

pub async fn execute<F, Fut>(
    kind: &JobKind,
    cancel: &CancellationToken,
    state: &Arc<DaemonState>,
    mut progress: F,
) -> Result<serde_json::Value, DaemonError>
where
    F: FnMut(&str, u8, &str) -> Fut,
    Fut: Future<Output = ()>,
{
    match kind {
        JobKind::Noop => noop::run().await,
        JobKind::Sleep { seconds } => sleep::run(*seconds, cancel).await,
        JobKind::ScanRun { req } => {
            #[cfg(feature = "offensive_ops")]
            {
                scan::run(req.clone(), cancel, &mut progress).await
            }
            #[cfg(not(feature = "offensive_ops"))]
            {
                let _ = req;
                Err(DaemonError::new(
                    ErrorCode::Forbidden,
                    "ScanRun disabled in this build",
                    false,
                ))
            }
        }
        JobKind::SystemUpdate { req } => {
            update::run(
                req.clone(),
                cancel,
                &mut progress,
                state.config.root_path.clone(),
                state.config.update_pubkey,
            )
            .await
        }
        JobKind::WifiScan { req } => wifi_scan::run(req.clone(), cancel, &mut progress).await,
        JobKind::WifiConnect { req } => wifi_connect::run(req.clone(), cancel, &mut progress).await,
        JobKind::HotspotStart { req } => hotspot_start::run(req.clone(), cancel, &mut progress).await,
        JobKind::PortalStart { req } => portal_start::run(req.clone(), cancel, &mut progress).await,
        JobKind::MountStart { req } => mount_start::run(req.clone(), cancel, &mut progress).await,
        JobKind::UnmountStart { req } => unmount_start::run(req.clone(), cancel, &mut progress).await,
        JobKind::InterfaceSelect { interface } => interface_select::run(interface.clone(), Arc::clone(state), cancel, &mut progress).await,
        JobKind::CoreCommand { command } => {
            #[cfg(feature = "core_dispatch")]
            {
                core_command::run(command.clone(), Arc::clone(state), cancel, &mut progress).await
            }
            #[cfg(not(feature = "core_dispatch"))]
            {
                let _ = command;
                Err(DaemonError::new(
                    ErrorCode::Forbidden,
                    "CoreCommand disabled in this build",
                    false,
                ))
            }
        }
    }
}
