use rustyjack_ipc::{DaemonError, ErrorCode, JobKind, ScanModeIpc, UiTestRunRequestIpc};

const MAX_INTERFACE_NAME_LEN: usize = 64;
const MAX_SSID_LEN: usize = 32;
const MAX_PSK_LEN: usize = 64;
const MIN_PSK_LEN: usize = 8;
const MAX_DEVICE_PATH_LEN: usize = 256;
const MAX_PORT: u16 = 65535;
const MIN_PORT: u16 = 1;
const MAX_TIMEOUT_MS: u64 = 3_600_000;
const MAX_SLEEP_SECONDS: u64 = 86400;
const MAX_SCAN_TARGET_LEN: usize = 256;
const MAX_SCAN_PORTS: usize = 128;
const MAX_TEST_ARG_COUNT: usize = 128;
const MAX_TEST_ARG_LEN: usize = 128;
const MAX_TEST_PATH_LEN: usize = 512;

pub fn validate_interface_name(interface: &str) -> Result<(), DaemonError> {
    if interface.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "interface name cannot be empty",
            false,
        ));
    }
    if interface.len() > MAX_INTERFACE_NAME_LEN {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "interface name too long",
            false,
        ));
    }
    if !interface
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
    {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "interface name contains invalid characters",
            false,
        ));
    }
    Ok(())
}

pub fn validate_ssid(ssid: &str) -> Result<(), DaemonError> {
    if ssid.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "SSID cannot be empty",
            false,
        ));
    }
    if ssid.len() > MAX_SSID_LEN {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "SSID too long (max 32 bytes)",
            false,
        ));
    }
    Ok(())
}

pub fn validate_psk(psk: &Option<String>) -> Result<(), DaemonError> {
    if let Some(ref passphrase) = psk {
        if passphrase.len() < MIN_PSK_LEN {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "PSK too short (min 8 characters)",
                false,
            ));
        }
        if passphrase.len() > MAX_PSK_LEN {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "PSK too long (max 64 characters)",
                false,
            ));
        }
    }
    Ok(())
}

pub fn validate_channel(channel: &Option<u8>) -> Result<(), DaemonError> {
    if let Some(ch) = channel {
        if *ch == 0 || *ch > 165 {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "invalid channel (must be 1-165)",
                false,
            ));
        }
    }
    Ok(())
}

pub fn validate_port(port: u16) -> Result<(), DaemonError> {
    if port < MIN_PORT || port > MAX_PORT {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "invalid port number",
            false,
        ));
    }
    if port < 1024 {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "privileged ports (<1024) not allowed",
            false,
        ));
    }
    Ok(())
}

pub fn validate_timeout_ms(timeout_ms: u64) -> Result<(), DaemonError> {
    if timeout_ms == 0 {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "timeout cannot be zero",
            false,
        ));
    }
    if timeout_ms > MAX_TIMEOUT_MS {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "timeout too large (max 1 hour)",
            false,
        ));
    }
    Ok(())
}

pub fn validate_device_path(device: &str) -> Result<(), DaemonError> {
    if device.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device path cannot be empty",
            false,
        ));
    }
    if device.len() > MAX_DEVICE_PATH_LEN {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device path too long",
            false,
        ));
    }
    if !device.starts_with('/') {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device path must be absolute",
            false,
        ));
    }
    if device.contains("..") {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device path contains directory traversal",
            false,
        ));
    }
    Ok(())
}

pub fn validate_filesystem(filesystem: &Option<String>) -> Result<(), DaemonError> {
    if let Some(ref fs) = filesystem {
        if fs.is_empty() {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "filesystem type cannot be empty",
                false,
            ));
        }
        let valid_filesystems = [
            "ext4", "ext3", "ext2", "vfat", "exfat", "ntfs", "ntfs-3g", "f2fs", "xfs", "btrfs",
        ];
        if !valid_filesystems.contains(&fs.as_str()) {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "unsupported filesystem type",
                false,
            ));
        }
    }
    Ok(())
}

pub fn validate_sleep_seconds(seconds: u64) -> Result<(), DaemonError> {
    if seconds == 0 {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "sleep duration cannot be zero",
            false,
        ));
    }
    if seconds > MAX_SLEEP_SECONDS {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "sleep duration too large (max 24 hours)",
            false,
        ));
    }
    Ok(())
}

fn validate_test_path_component(value: &str, field: &str) -> Result<(), DaemonError> {
    if value.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            format!("{field} cannot be empty"),
            false,
        ));
    }
    if value.len() > MAX_TEST_PATH_LEN {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            format!("{field} too long"),
            false,
        ));
    }
    if value.contains('\0') || value.chars().any(|c| c.is_control()) {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            format!("{field} contains invalid characters"),
            false,
        ));
    }
    Ok(())
}

pub fn validate_ui_test_run_request(req: &UiTestRunRequestIpc) -> Result<(), DaemonError> {
    if let Some(scripts_dir) = req.scripts_dir.as_deref() {
        validate_test_path_component(scripts_dir, "scripts_dir")?;
    }
    if let Some(outroot) = req.outroot.as_deref() {
        validate_test_path_component(outroot, "outroot")?;
    }
    if let Some(run_id) = req.run_id.as_deref() {
        validate_test_path_component(run_id, "run_id")?;
    }

    if req.args.len() > MAX_TEST_ARG_COUNT {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "too many test arguments",
            false,
        ));
    }
    for arg in &req.args {
        if arg.is_empty() {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "test argument cannot be empty",
                false,
            ));
        }
        if arg.len() > MAX_TEST_ARG_LEN {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "test argument too long",
                false,
            ));
        }
        if arg.contains('\0') || arg.chars().any(|c| c.is_control()) {
            return Err(DaemonError::new(
                ErrorCode::BadRequest,
                "test argument contains invalid characters",
                false,
            ));
        }
    }
    Ok(())
}

pub fn validate_scan_target(target: &str) -> Result<(), DaemonError> {
    if target.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "scan target cannot be empty",
            false,
        ));
    }
    if target.len() > MAX_SCAN_TARGET_LEN {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "scan target too long",
            false,
        ));
    }
    if target.chars().any(|c| c.is_control()) {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "scan target contains control characters",
            false,
        ));
    }
    Ok(())
}

pub fn validate_scan_ports(mode: ScanModeIpc, ports: Option<&[u16]>) -> Result<(), DaemonError> {
    match mode {
        ScanModeIpc::DiscoveryOnly => {
            if ports.is_some() && !ports.unwrap().is_empty() {
                return Err(DaemonError::new(
                    ErrorCode::BadRequest,
                    "ports must be empty for DiscoveryOnly mode",
                    false,
                ));
            }
        }
        ScanModeIpc::DiscoveryAndPorts => {
            if let Some(port_list) = ports {
                if port_list.is_empty() {
                    return Err(DaemonError::new(
                        ErrorCode::BadRequest,
                        "ports cannot be empty for DiscoveryAndPorts mode",
                        false,
                    ));
                }
                if port_list.len() > MAX_SCAN_PORTS {
                    return Err(DaemonError::new(
                        ErrorCode::BadRequest,
                        "too many ports (max 128)",
                        false,
                    ));
                }
                for &port in port_list {
                    validate_port(port)?;
                }
            } else {
                return Err(DaemonError::new(
                    ErrorCode::BadRequest,
                    "ports required for DiscoveryAndPorts mode",
                    false,
                ));
            }
        }
    }
    Ok(())
}

pub fn validate_update_url(url: &str) -> Result<(), DaemonError> {
    let trimmed = url.trim();
    if trimmed.is_empty() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "update url cannot be empty",
            false,
        ));
    }
    if trimmed.len() > 2048 {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "update url too long",
            false,
        ));
    }
    if !trimmed.starts_with("https://") {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "update url must use https://",
            false,
        ));
    }
    if trimmed.chars().any(|c| c.is_control() || c.is_whitespace()) {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "update url contains invalid characters",
            false,
        ));
    }
    Ok(())
}

pub fn validate_mount_device_hint(device: &str) -> Result<(), DaemonError> {
    validate_device_path(device)?;

    if !device.starts_with("/dev/") {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device path must start with /dev/",
            false,
        ));
    }

    if device.starts_with("/dev/mmcblk") || device.starts_with("/dev/loop") {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "mounting internal mmc or loop devices not allowed",
            false,
        ));
    }

    #[cfg(target_os = "linux")]
    {
        validate_removable_block_device(device)?;
    }

    Ok(())
}

#[cfg(target_os = "linux")]
fn validate_removable_block_device(device: &str) -> Result<(), DaemonError> {
    use std::os::unix::fs::{FileTypeExt, MetadataExt};
    use std::path::Path;

    let path = Path::new(device);
    let meta = std::fs::symlink_metadata(path).map_err(|e| {
        DaemonError::new(ErrorCode::BadRequest, "cannot stat device", false)
            .with_detail(e.to_string())
    })?;

    if meta.file_type().is_symlink() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device must not be a symlink",
            false,
        ));
    }

    if !meta.file_type().is_block_device() {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device is not a block device",
            false,
        ));
    }

    let rdev = meta.rdev();
    let major = ((rdev >> 8) & 0xfff) as u32;
    let minor = ((rdev & 0xff) | ((rdev >> 12) & 0xfff00)) as u32;
    let sys_base = Path::new("/sys/dev/block").join(format!("{}:{}", major, minor));
    let sys_real = std::fs::canonicalize(&sys_base).unwrap_or(sys_base);
    let removable = std::fs::read_to_string(sys_real.join("removable"))
        .or_else(|_| {
            let parent = sys_real.parent().ok_or_else(|| {
                std::io::Error::new(std::io::ErrorKind::NotFound, "no sysfs parent")
            })?;
            std::fs::read_to_string(parent.join("removable"))
        })
        .map_err(|e| {
            DaemonError::new(
                ErrorCode::BadRequest,
                "failed to read removable flag",
                false,
            )
            .with_detail(e.to_string())
        })?;

    if removable.trim() != "1" {
        return Err(DaemonError::new(
            ErrorCode::BadRequest,
            "device not removable",
            false,
        ));
    }

    Ok(())
}

pub fn validate_job_kind(kind: &JobKind) -> Result<(), DaemonError> {
    match kind {
        JobKind::Noop => Ok(()),
        JobKind::Sleep { seconds } => validate_sleep_seconds(*seconds),
        JobKind::ScanRun { req } => {
            validate_scan_target(&req.target)?;
            validate_timeout_ms(req.timeout_ms)?;
            validate_scan_ports(req.mode.clone(), req.ports.as_deref())?;
            Ok(())
        }
        JobKind::SystemUpdate { req } => {
            validate_update_url(&req.url)?;
            Ok(())
        }
        JobKind::WifiScan { req } => {
            validate_interface_name(&req.interface)?;
            validate_timeout_ms(req.timeout_ms)?;
            Ok(())
        }
        JobKind::WifiConnect { req } => {
            validate_interface_name(&req.interface)?;
            validate_ssid(&req.ssid)?;
            validate_psk(&req.psk)?;
            validate_timeout_ms(req.timeout_ms)?;
            Ok(())
        }
        JobKind::HotspotStart { req } => {
            validate_interface_name(&req.interface)?;
            validate_ssid(&req.ssid)?;
            validate_psk(&req.passphrase)?;
            validate_channel(&req.channel)?;
            Ok(())
        }
        JobKind::PortalStart { req } => {
            validate_interface_name(&req.interface)?;
            validate_port(req.port)?;
            Ok(())
        }
        JobKind::MountStart { req } => {
            validate_mount_device_hint(&req.device)?;
            validate_filesystem(&req.filesystem)?;
            Ok(())
        }
        JobKind::UnmountStart { req } => {
            validate_mount_device_hint(&req.device)?;
            Ok(())
        }
        JobKind::InterfaceSelect { interface } => {
            validate_interface_name(interface)?;
            Ok(())
        }
        JobKind::UiTestRun { req } => validate_ui_test_run_request(req),
        JobKind::CoreCommand { .. } => Ok(()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rustyjack_ipc::{
        JobKind, MountStartRequestIpc, ScanModeIpc, ScanRequestIpc, WifiConnectRequestIpc,
    };

    #[test]
    fn test_validate_mount_device_rejects_mmcblk() {
        let result = validate_mount_device_hint("/dev/mmcblk0p1");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(err.code, ErrorCode::BadRequest);
        assert!(err.message.contains("mmcblk"));
    }

    #[test]
    fn test_validate_mount_device_rejects_loop() {
        let result = validate_mount_device_hint("/dev/loop0");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(err.code, ErrorCode::BadRequest);
        assert!(err.message.contains("loop"));
    }

    #[test]
    fn test_validate_mount_device_requires_dev_prefix() {
        let result = validate_mount_device_hint("/mnt/usb");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(err.code, ErrorCode::BadRequest);
        assert!(err.message.contains("/dev/"));
    }

    #[test]
    #[cfg(target_os = "linux")]
    fn test_validate_mount_device_accepts_sda() {
        let path = "/dev/sda1";
        if is_removable_block_device(path) {
            let result = validate_mount_device_hint(path);
            assert!(result.is_ok());
        }
    }

    #[cfg(target_os = "linux")]
    fn is_removable_block_device(path: &str) -> bool {
        use std::os::unix::fs::{FileTypeExt, MetadataExt};
        use std::path::Path;

        let meta = match std::fs::symlink_metadata(Path::new(path)) {
            Ok(meta) => meta,
            Err(_) => return false,
        };
        if meta.file_type().is_symlink() || !meta.file_type().is_block_device() {
            return false;
        }

        let rdev = meta.rdev();
        let major = ((rdev >> 8) & 0xfff) as u32;
        let minor = ((rdev & 0xff) | ((rdev >> 12) & 0xfff00)) as u32;
        let sys_path = Path::new("/sys/dev/block")
            .join(format!("{}:{}", major, minor))
            .join("removable");

        match std::fs::read_to_string(&sys_path) {
            Ok(val) => val.trim() == "1",
            Err(_) => false,
        }
    }

    #[test]
    fn test_validate_filesystem_accepts_common_types() {
        assert!(validate_filesystem(&Some("ext4".to_string())).is_ok());
        assert!(validate_filesystem(&Some("vfat".to_string())).is_ok());
        assert!(validate_filesystem(&Some("exfat".to_string())).is_ok());
        assert!(validate_filesystem(&Some("ntfs".to_string())).is_ok());
    }

    #[test]
    fn test_validate_filesystem_rejects_unknown() {
        let result = validate_filesystem(&Some("invalid_fs".to_string()));
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_channel_rejects_zero() {
        let result = validate_channel(&Some(0));
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_channel_rejects_out_of_range() {
        let result = validate_channel(&Some(166));
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_channel_accepts_valid() {
        assert!(validate_channel(&Some(1)).is_ok());
        assert!(validate_channel(&Some(11)).is_ok());
        assert!(validate_channel(&Some(165)).is_ok());
    }

    #[test]
    fn test_validate_port_rejects_privileged() {
        let result = validate_port(80);
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert!(err.message.contains("1024"));
    }

    #[test]
    fn test_validate_port_accepts_high_ports() {
        assert!(validate_port(8080).is_ok());
        assert!(validate_port(3000).is_ok());
    }

    #[test]
    fn test_validate_sleep_seconds_rejects_zero() {
        let result = validate_sleep_seconds(0);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_sleep_seconds_rejects_too_large() {
        let result = validate_sleep_seconds(MAX_SLEEP_SECONDS + 1);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_job_kind_mount_rejects_mmcblk() {
        let kind = JobKind::MountStart {
            req: MountStartRequestIpc {
                device: "/dev/mmcblk0p1".to_string(),
                filesystem: None,
            },
        };
        let result = validate_job_kind(&kind);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_job_kind_wifi_connect_requires_valid_ssid() {
        let kind = JobKind::WifiConnect {
            req: WifiConnectRequestIpc {
                interface: "wlan0".to_string(),
                ssid: "".to_string(),
                psk: None,
                timeout_ms: 30000,
            },
        };
        let result = validate_job_kind(&kind);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_job_kind_scan_rejects_empty_target() {
        let kind = JobKind::ScanRun {
            req: ScanRequestIpc {
                target: "".to_string(),
                mode: ScanModeIpc::DiscoveryOnly,
                ports: None,
                timeout_ms: 60000,
            },
        };
        let result = validate_job_kind(&kind);
        assert!(result.is_err());
    }

    #[test]
    fn test_validate_update_url_requires_https() {
        assert!(validate_update_url("https://example.com/update.tar.zst").is_ok());
        assert!(validate_update_url("http://example.com/update.tar.zst").is_err());
        assert!(validate_update_url("").is_err());
    }

    #[test]
    fn test_validate_update_url_rejects_whitespace() {
        assert!(validate_update_url("https://example.com/space here").is_err());
    }
}
