# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/physical_access
- Tests: 3
- Passed: 2
- Failed: 4
- Skipped: 2

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/physical_access/run.log
- /var/tmp/rustyjack-tests/20260215-204314/physical_access/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/physical_access/report.md
