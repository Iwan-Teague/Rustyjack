# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/theme
- Tests: 2
- Passed: 32
- Failed: 1
- Skipped: 3

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/theme/run.log
- /var/tmp/rustyjack-tests/20260215-204314/theme/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/theme/report.md
