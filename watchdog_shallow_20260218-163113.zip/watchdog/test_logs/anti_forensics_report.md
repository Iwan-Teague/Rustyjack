# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/anti_forensics
- Tests: 4
- Passed: 1
- Failed: 8
- Skipped: 2

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/anti_forensics/run.log
- /var/tmp/rustyjack-tests/20260215-204314/anti_forensics/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/anti_forensics/report.md
