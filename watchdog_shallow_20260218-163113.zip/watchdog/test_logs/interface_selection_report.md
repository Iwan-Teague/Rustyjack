# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/interface_selection
- Tests: 18
- Passed: 22
- Failed: 8
- Skipped: 1

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/interface_selection/run.log
- /var/tmp/rustyjack-tests/20260215-204314/interface_selection/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/interface_selection/report.md
