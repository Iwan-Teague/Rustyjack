# Rustyjack Test Report

- Run: 20260215-204314
- Output: /var/tmp/rustyjack-tests/20260215-204314/daemon
- Tests: 6
- Passed: 11
- Failed: 5
- Skipped: 4

Artifacts:
- /var/tmp/rustyjack-tests/20260215-204314/daemon/run.log
- /var/tmp/rustyjack-tests/20260215-204314/daemon/summary.jsonl
- /var/tmp/rustyjack-tests/20260215-204314/daemon/report.md

## Daemon Test Summary
- Service: rustyjackd.service
- Socket: /run/rustyjack/rustyjackd.sock
- Operator group: rustyjack
- Admin group: rustyjack-admin
- Comprehensive suite: enabled
